import socket

# تنظیمات سرور
host = '127.6.7.1'  # آدرس IP لوکال
port = 37691         # پورت برای ارتباط

# ایجاد سوکت
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# اتصال به پورت
server_socket.bind((host, port))

# گوش دادن به درخواست‌های ورودی
server_socket.listen(1)
print(f"Server listening on {host}:{port}...")

# پذیرش اتصال از کلاینت
client_socket, client_address = server_socket.accept()
print(f"Connection from {client_address} has been established.")

# ارتباط چت
while True:
    message = client_socket.recv(1024).decode('utf-8')
    if message.lower() == 'bye':
        print("Connection closed by client.")
        break
    print(f"Client: {message}")
    
    reply = input("Server: ")
    client_socket.send(reply.encode('utf-8'))
    if reply.lower() == 'bye':
        print("Connection closed by server.")
        break

# بستن اتصال
client_socket.close()
server_socket.close()
#Nima Mohit 99433057
