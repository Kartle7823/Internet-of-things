import socket

# تنظیمات سرور
host = '127.6.7.1'  # آدرس IP سرور
port = 37691         # پورت برای ارتباط

# ایجاد سوکت
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# اتصال به سرور
client_socket.connect((host, port))
print(f"Connected to server at {host}:{port}.")

# ارتباط چت
while True:
    message = input("Client: ")
    client_socket.send(message.encode('utf-8'))
    if message.lower() == 'bye':
        print("Connection closed by client.")
        break
    
    reply = client_socket.recv(1024).decode('utf-8')
    print(f"Server: {reply}")
    if reply.lower() == 'bye':
        print("Connection closed by server.")
        break

# بستن اتصال
client_socket.close()
#Nima Mohit 99433057
