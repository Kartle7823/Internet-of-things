# گام 1: وارد کردن کتابخانه‌ها
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, Dense, LSTM, Dropout
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt

# گام 2: شبیه‌سازی داده‌های ترافیک شبکه (این مرحله را می‌توانید با داده‌های واقعی جایگزین کنید)
# شبیه‌سازی داده‌ها (ویژگی‌ها: طول بسته، زمان درخواست، تعداد بسته‌ها)
np.random.seed(42)
n_samples = 1000
time_steps = 10  # تعداد گام‌های زمانی

# ویژگی‌های شبیه‌سازی شده (مثال: طول بسته، زمان درخواست، تعداد بسته‌ها)
packet_length = np.random.normal(100, 20, (n_samples, time_steps))
request_time = np.random.normal(50, 10, (n_samples, time_steps))
packet_count = np.random.normal(10, 2, (n_samples, time_steps))

# حملات: 0 برای رفتار طبیعی و 1 برای حملات (مثل DDoS)
attacks = np.random.choice([0, 1], size=(n_samples, 1), p=[0.9, 0.1])

# داده‌ها: ترکیب ویژگی‌ها
data = np.concatenate([packet_length, request_time, packet_count], axis=-1)

# تبدیل به یک DataFrame
df = pd.DataFrame(data.reshape(n_samples, -1))
df['Attack'] = attacks

# گام 3: پیش‌پردازش داده‌ها
# استانداردسازی داده‌ها
scaler = StandardScaler()
X = df.drop(columns=['Attack']).values
y = df['Attack'].values

X_scaled = scaler.fit_transform(X)

# تبدیل داده‌ها به قالب مناسب برای RNN (ورودی به صورت دنباله زمانی)
X_scaled = X_scaled.reshape(n_samples, time_steps, 3)  # (تعداد نمونه‌ها، تعداد گام‌های زمانی، تعداد ویژگی‌ها)

# تقسیم داده‌ها به مجموعه آموزش و تست (80% آموزش، 20% تست)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# گام 4: ساخت مدل RNN
model = Sequential()
model.add(LSTM(units=50, return_sequences=False, input_shape=(time_steps, 3)))
model.add(Dropout(0.2))  # Dropout برای جلوگیری از overfitting
model.add(Dense(units=1, activation='sigmoid'))  # چون هدف دو دسته‌ای است (حمله یا غیرحمله)

# کامپایل مدل
model.compile(optimizer=Adam(), loss='binary_crossentropy', metrics=['accuracy'])

# گام 5: آموزش مدل
history = model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test))

# گام 6: ارزیابی مدل
y_pred = model.predict(X_test)
y_pred = (y_pred > 0.5)  # تبدیل به برچسب‌های 0 و 1

# ارزیابی مدل
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy * 100:.2f}%")
print("\nClassification Report:")
print(classification_report(y_test, y_pred))

# گام 7: نتایج
# ترسیم نمودار دقت و از دست دادن در طول دوره‌ها
plt.plot(history.history['accuracy'], label='دقت (Train)')
plt.plot(history.history['val_accuracy'], label='دقت (Test)')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.title('Training and Testing Accuracy')

plt.show()
