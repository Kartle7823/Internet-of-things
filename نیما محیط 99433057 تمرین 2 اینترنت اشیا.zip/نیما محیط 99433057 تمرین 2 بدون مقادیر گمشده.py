import numpy as np
import pandas as pd

# تولید داده‌های تصادفی
np.random.seed(42)
n_samples = 1000

# تولید داده‌های تصادفی برای ویژگی‌ها
temperature = np.random.uniform(0, 35, n_samples)  # دما بین 0 تا 35 درجه سانتی‌گراد
hour = np.random.randint(0, 24, n_samples)  # ساعت روز (بین 0 تا 23)

# تولید هدف (مصرف انرژی فرضی)
energy_consumption = 50 + 2 * temperature + 0.5 * hour + np.random.normal(0, 5, n_samples)  # مدل ساده

# ساخت دیتافریم
data = pd.DataFrame({'Temperature': temperature, 'Hour': hour, 'EnergyConsumption': energy_consumption})

# نمایش پنج ردیف اول داده‌ها
print(data.head())

# بررسی داده‌های گمشده
print(data.isnull().sum())

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# تقسیم داده‌ها به ویژگی‌ها و هدف
X = data[['Temperature', 'Hour']]  # ویژگی‌ها
y = data['EnergyConsumption']  # هدف

# تقسیم داده‌ها به مجموعه‌های آموزش و تست (80% آموزش و 20% تست)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# مقیاس‌بندی ویژگی‌ها (در صورتی که نیاز باشد)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR

# مدل‌های مختلف
models = {
    "Linear Regression": LinearRegression(),
    "Decision Tree": DecisionTreeRegressor(random_state=42),
    "Random Forest": RandomForestRegressor(random_state=42),
    "Support Vector Machine": SVR()
}

# آموزش مدل‌ها
for name, model in models.items():
    model.fit(X_train_scaled, y_train)
    print(f"مدل {name} آموزش داده شد.")

from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

# ارزیابی مدل‌ها
results = {}
for name, model in models.items():
    y_pred = model.predict(X_test_scaled)
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_test, y_pred)
    
    results[name] = {"MAE": mae, "MSE": mse, "RMSE": rmse, "R^2": r2}

# نمایش نتایج ارزیابی
results_df = pd.DataFrame(results).T
print(results_df)
# اهمیت ویژگی‌ها با استفاده از درخت تصمیم
tree_model = models["Decision Tree"]
feature_importance = tree_model.feature_importances_

# نمایش اهمیت ویژگی‌ها
for feature, importance in zip(X.columns, feature_importance):
    print(f"ویژگی {feature} دارای اهمیت {importance:.4f}")
# بررسی ضرایب رگرسیون خطی
linear_model = models["Linear Regression"]
coefficients = linear_model.coef_

# نمایش ضرایب
for feature, coef in zip(X.columns, coefficients):
    print(f"ویژگی {feature} دارای ضریب {coef:.4f}")
