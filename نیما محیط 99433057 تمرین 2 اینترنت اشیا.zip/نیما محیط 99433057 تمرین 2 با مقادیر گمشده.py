# گام 1: وارد کردن کتابخانه‌ها
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.impute import SimpleImputer

# گام 2: شبیه‌سازی داده‌ها
np.random.seed(42)
n_samples = 1000
temperature = np.random.uniform(0, 35, n_samples)
hour = np.random.randint(0, 24, n_samples)
energy_consumption = 50 + 2 * temperature + 0.5 * hour + np.random.normal(0, 5, n_samples)

# ساخت دیتافریم
data = pd.DataFrame({
    'Temperature': temperature,
    'Hour': hour,
    'EnergyConsumption': energy_consumption
})

# گام 3: اضافه کردن مقادیر گمشده به صورت تصادفی (10% از داده‌ها را گم می‌کنیم)
missing_percentage = 0.1
n_missing_temp = int(len(data) * missing_percentage)
missing_indices_temp = np.random.choice(data.index, size=n_missing_temp, replace=False)
data.loc[missing_indices_temp, 'Temperature'] = np.nan

n_missing_hour = int(len(data) * missing_percentage)
missing_indices_hour = np.random.choice(data.index, size=n_missing_hour, replace=False)
data.loc[missing_indices_hour, 'Hour'] = np.nan

# بررسی مقادیر گمشده
print("مقادیر گمشده در هر ویژگی:")
print(data.isnull().sum())

# گام 4: پیش‌پردازش داده‌ها
# استفاده از SimpleImputer برای پر کردن مقادیر گمشده با میانگین
imputer = SimpleImputer(strategy='mean')
data_imputed = pd.DataFrame(imputer.fit_transform(data), columns=data.columns)

# بررسی پس از پیش‌پردازش
print("\nپس از پر کردن مقادیر گمشده:")
print(data_imputed.head())

# گام 5: تقسیم داده‌ها به مجموعه‌های آموزش و تست
X = data_imputed[['Temperature', 'Hour']]  # ویژگی‌ها
y = data_imputed['EnergyConsumption']      # هدف

# تقسیم داده‌ها به آموزش و تست (80% آموزش، 20% تست)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# گام 6: مقیاس‌بندی داده‌ها (برای مدل‌های حساس به مقیاس مانند رگرسیون خطی و SVM)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# گام 7: آموزش مدل‌ها

# رگرسیون خطی
lr_model = LinearRegression()
lr_model.fit(X_train_scaled, y_train)

# درخت تصمیم
dt_model = DecisionTreeRegressor(random_state=42)
dt_model.fit(X_train, y_train)

# جنگل تصادفی
rf_model = RandomForestRegressor(random_state=42)
rf_model.fit(X_train, y_train)

# ماشین بردار پشتیبان
svm_model = SVR()
svm_model.fit(X_train_scaled, y_train)

# گام 8: ارزیابی مدل‌ها

# پیش‌بینی‌ها
lr_pred = lr_model.predict(X_test_scaled)
dt_pred = dt_model.predict(X_test)
rf_pred = rf_model.predict(X_test)
svm_pred = svm_model.predict(X_test_scaled)

# محاسبه معیارهای ارزیابی
models = ['Linear Regression', 'Decision Tree', 'Random Forest', 'Support Vector Machine']
predictions = [lr_pred, dt_pred, rf_pred, svm_pred]

mae = []
mse = []
rmse = []
r2 = []

for pred in predictions:
    mae.append(mean_absolute_error(y_test, pred))
    mse.append(mean_squared_error(y_test, pred))
    rmse.append(np.sqrt(mean_squared_error(y_test, pred)))
    r2.append(r2_score(y_test, pred))

# نمایش نتایج
results = pd.DataFrame({
    'Model': models,
    'MAE': mae,
    'MSE': mse,
    'RMSE': rmse,
    'R²': r2
})

print("\nنتایج ارزیابی مدل‌ها:")
print(results)

# گام 9: تحلیل ویژگی‌ها

# مهم‌ترین ویژگی‌ها در مدل جنگل تصادفی
rf_importances = rf_model.feature_importances_

# مهم‌ترین ویژگی‌ها در مدل رگرسیون خطی (ضرایب)
lr_coefficients = lr_model.coef_

print("\nاهمیت ویژگی‌ها در مدل جنگل تصادفی:")
for feature, importance in zip(X.columns, rf_importances):
    print(f"{feature}: {importance:.4f}")

print("\nضرایب ویژگی‌ها در مدل رگرسیون خطی:")
for feature, coef in zip(X.columns, lr_coefficients):
    print(f"{feature}: {coef:.4f}")

